package ru.ulstu.chistikovacoursework;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChistikovaCourseworkApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChistikovaCourseworkApplication.class, args);
	}

}
